#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

source_file="${1:-main.mx}"
if [[ "$source_file" != *.mx || ! -f "$source_file" ]]; then
    echo "Usage: bash compile.sh [main.mx|examples/hello.mx]" >&2
    exit 2
fi
for tool in python3 clang lld-link; do
    command -v "$tool" >/dev/null || { echo "Missing tool: $tool" >&2; exit 2; }
done
if command -v cc >/dev/null; then
    host_cc=cc
else
    host_cc=clang
fi

name="$(basename "$source_file" .mx)"
mkdir -p build/EFI/BOOT
"$host_cc" -std=c11 -O2 -Wall -Wextra compiler/mxc.c -o build/mxc
build/mxc "$source_file" build/generated.c

target_flags=(-target x86_64-pc-win32 -ffreestanding -fshort-wchar
              -fno-stack-protector -fno-builtin -O2 -Iruntime)
sources=(mx_runtime mx_lowlevel mx_http mx_browser_text mx_browser_layout
         mx_browser_js mxWiFi mxEthernet)
objects=()
for unit in "${sources[@]}"; do
    clang "${target_flags[@]}" -c "runtime/$unit.c" -o "build/$unit.obj"
    objects+=("build/$unit.obj")
done
clang "${target_flags[@]}" -c build/generated.c -o build/generated.obj
objects+=(build/generated.obj)
lld-link /subsystem:efi_application /entry:efi_main /nodefaultlib \
    /out:build/BOOTX64.EFI "${objects[@]}"
cp build/BOOTX64.EFI build/EFI/BOOT/BOOTX64.EFI
python3 compiler/make_uefi_iso.py build "$name"
echo "Ready: build/$name.iso"
