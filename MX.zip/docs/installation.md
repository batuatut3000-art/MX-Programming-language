# Installation and build (Linux / WSL Ubuntu)

Required tools: Python 3, Clang, LLD (`lld-link`), a C compiler, QEMU, and OVMF firmware.

On Ubuntu, the package names usually include `python3`, `clang`, `lld`, `build-essential`, `qemu-system-x86`, and `ovmf`.

From the repository root:

```bash
bash compile.sh main.mx
bash run-qemu.sh main
```

The first command builds `build/main.iso`. Set `MX_OVMF_CODE` if your firmware image is in a different location.

> The source currently targets UEFI x86_64; it is not a standalone kernel. Hardware behavior depends on firmware services.
